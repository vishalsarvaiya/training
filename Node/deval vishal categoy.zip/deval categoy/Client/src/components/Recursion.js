import axios from 'axios';
import React, { useState, useEffect } from 'react'

function Recursion({ item }) {
    const [childData, setChildData] = useState([]);
    const [edit, setEdit] = useState("");
    const [btn, setBtn] = useState(false);

    // useEffect(() => {
    //     if (item) {
    //         getChildData();
    //     }
    // }, []);

    useEffect(() => {
        console.log(item);
        getChild();
    }, [])
    const getChild = async () => {
        try {
            const data = await axios.get("http://localhost:8000/getchild", { params: { id: item.recid } })
            setChildData(data.data);
        } catch (err) {
            console.log(err);
        }
    }

    const deleteData = (id) => {
        console.log(id);
        try {
            axios.get("http://localhost:8000/deleteDatas", { params: { id } });
        } catch (error) {
            console.log(error);
        }
    };

    const editCategory = () => {
        try {
            console.log(edit);
            axios
                .get("http://localhost:8000/editDatas", { params: { edit, data: item.recid } })
                .then((res) => {
                    console.log(res);
                });
        } catch (error) {
            console.log(error);
        }
    };

    return (
        <div style={{ "marginLeft": "50px" }}>
            {/* <p>{item.category}</p> */}

            <span>
                &gt; {item.category}
                {btn ? (
                    <>

                        <input
                            type="text"
                            value={edit}
                            placeholder="Edit data"
                            onChange={(e) => {
                                setEdit(e.target.value);
                            }}
                        />

                        <button
                            onClick={() => {
                                editCategory();
                            }}
                        >
                            Update
                        </button>

                    </>
                ) : (
                    <>
                        <button
                            onClick={() => {
                                setBtn(true);
                            }}
                        >
                            Edit
                        </button>

                    </>
                )}
                <button onClick={() => deleteData(item.recid)}>delete</button>
            </span>


            {childData.map((item1) => (
                <Recursion item={item1} />
            ))}
        </div>
    )
}

export default Recursion