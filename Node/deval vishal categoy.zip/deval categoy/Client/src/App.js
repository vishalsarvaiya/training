import logo from './logo.svg';
import './App.css';
import Category_form from './components/Category_form';

function App() {
  return (
   <Category_form/>
  );
}

export default App;
